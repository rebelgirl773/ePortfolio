

/**
 * Represents a Task with a unique ID, name, and description.
 * Ensures that all fields are properly validated upon object creation.
 */
public class Task {
    private String taskId;
    private String name;
    private String description;

    /**
     * Constructs a Task object with the given ID, name, and description.
     *
     * @param taskId Unique identifier for the task (must be non-null and <= 10 characters)
     * @param name Name of the task (must be non-null and <= 20 characters)
     * @param description Description of the task (must be non-null and <= 50 characters)
     * @throws IllegalArgumentException if any validation checks fail
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must be non-null and at most 10 characters long.");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name must be non-null and at most 20 characters long.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description must be non-null and at most 50 characters long.");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    /**
     * Gets the task ID.
     * @return task ID
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * Gets the task name.
     * @return task name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the task description.
     * @return task description
     */
    public String getDescription() {
        return description;
    }
}



import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Manages Task objects using a thread-safe ConcurrentHashMap.
 * Provides methods to add, delete, and update tasks.
 */
public class TaskService {
    private Map<String, Task> tasks;

    /**
     * Constructs a TaskService with an empty task list.
     */
    public TaskService() {
        this.tasks = new ConcurrentHashMap<>();
    }

    /**
     * Adds a new task to the service.
     * @param task The task to be added.
     * @throws IllegalArgumentException if task ID already exists.
     */
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    /**
     * Deletes a task by its task ID.
     * @param taskId The task ID to remove.
     * @throws IllegalArgumentException if task ID does not exist.
     */
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        tasks.remove(taskId);
    }

    /**
     * Updates the name of a task.
     * @param taskId The ID of the task to update.
     * @param newName The new name to assign.
     * @throws IllegalArgumentException if task ID not found or new name is invalid.
     */
    public void updateTaskName(String taskId, String newName) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        Task task = tasks.get(taskId);
        task = new Task(taskId, newName, task.getDescription());
        tasks.put(taskId, task);
    }

    /**
     * Updates the description of a task.
     * @param taskId The ID of the task to update.
     * @param newDescription The new description to assign.
     * @throws IllegalArgumentException if task ID not found or new description is invalid.
     */
    public void updateTaskDescription(String taskId, String newDescription) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        Task task = tasks.get(taskId);
        task = new Task(taskId, task.getName(), newDescription);
        tasks.put(taskId, task);
    }
}

