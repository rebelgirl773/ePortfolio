-- Enhanced database schema for the food tracking app
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE meals (
    meal_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    meal_name VARCHAR(100) NOT NULL,
    meal_time DATETIME NOT NULL,
    total_calories INT NOT NULL,
    protein FLOAT NOT NULL,
    carbs FLOAT NOT NULL,
    fats FLOAT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Added indexes to improve query performance
CREATE INDEX idx_meals_user_id ON meals(user_id);
CREATE INDEX idx_meals_meal_time ON meals(meal_time);

-- Function to generate weekly nutrition report
DELIMITER //
CREATE FUNCTION generate_weekly_report(userId INT, startDate DATE, endDate DATE)
RETURNS TABLE
BEGIN
    RETURN (
        SELECT SUM(total_calories) AS total_calories,
               AVG(protein) AS avg_protein,
               AVG(carbs) AS avg_carbs,
               AVG(fats) AS avg_fats
        FROM meals
        WHERE user_id = userId AND meal_time BETWEEN startDate AND endDate
    );
END //
DELIMITER ;

-- Firebase integration for real-time synchronization (Pseudo implementation)
-- In application code (Python example using Firebase SDK)
import firebase_admin
from firebase_admin import credentials, db

cred = credentials.Certificate("path/to/firebase/credentials.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://your-database-url.firebaseio.com/'
})

# Sync new meal entry with Firebase
meal_data = {
    "user_id": 1,
    "meal_name": "Chicken Salad",
    "meal_time": "2025-02-09 12:30:00",
    "total_calories": 400,
    "protein": 35,
    "carbs": 20,
    "fats": 10
}
ref = db.reference('meals')
ref.push(meal_data)

-- Enhanced security: Encrypting user passwords before storing
UPDATE users
SET password_hash = SHA2(password_hash, 256);
